export interface Order {
  _id: string;
  amount: number;
}