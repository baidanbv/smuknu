export interface LayoutPageProps {
  handleCart: () => void;
  isEmptyCart: boolean;
  toggleMenu: () => void;
  isOpenMenu: boolean;
}
