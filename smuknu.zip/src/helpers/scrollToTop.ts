export  const scrollToTop = (): void => {
  window.scrollTo(0, 0);
};
